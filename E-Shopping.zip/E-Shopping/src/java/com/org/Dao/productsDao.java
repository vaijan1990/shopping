/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.Dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Your Name <Vj>
 */
public class productsDao {
    private static Connection con;
    public static String getProductCount(int id) {
         String recCount="";
        try{  
           
con=DBConnection.connect(); 
      
PreparedStatement ps=con.prepareStatement(  
"select count(*) as count from shop.items where item_class_id=?");
ps.setInt(1, id);
 ResultSet rs=ps.executeQuery();  
 while(rs.next())
 {
     recCount=rs.getString("count");
      System.out.println("recCount"+recCount);
 }

//con.close();
        }
        catch(Exception e){System.out.println(e);}  
       
      return recCount;
    }
    
    public static String[] getProducts(int id,int count) {
         String[] products=new String[count];
         int i=0;
                 try{       
con=DBConnection.connect();       
PreparedStatement ps=con.prepareStatement(  
"select item_id||';'||item_name||';'||item_image_name||';'||item_unit_price||';'||item_discount_percent as productList from shop.items where item_class_id=?");
ps.setInt(1, id);
 ResultSet rs=ps.executeQuery();  
 while(rs.next())
 {
     products[i]=rs.getString("productList");
      System.out.println("productsList"+products[i]);
      i++;
 }

        }
        catch(Exception e){System.out.println(e);}  
       
      return products;
    }
    
    public static String[] getCartItems(String order_item)
    {
        String[] cart_items=order_item.split(";");
        String query="select item_id||';'||item_name||';'||item_image_name||';'||item_unit_price||';'||item_discount_percent as productList from shop.items where item_id in (";
        int listLength=cart_items.length;
        System.out.println("listLength "+listLength);
        String appender="";
        String[] itemsList=new String[listLength];
        
        for (int i=0;i<listLength;i++){
            appender+="?";
            if(i!=listLength-1){
                appender+=",";
            }
        }
        query=query+appender+")";
        System.out.println("Query"+query);
        try{
            con=DBConnection.connect();
            PreparedStatement ps=con.prepareStatement(query);
            for(int j=0; j<listLength;j++){
                ps.setInt(j+1,Integer.parseInt(cart_items[j]));
                System.out.println("set parameters: "+cart_items[j]);
            } 
            ResultSet rs=ps.executeQuery();
            int loopcount=0;
            while(rs.next()){
               itemsList[loopcount] = rs.getString("productList");
               System.out.println("loopcount "+loopcount);
               System.out.println("itemsList[loopcount] "+itemsList[loopcount]);
               loopcount++;
            }
        }
        
         catch(Exception e){System.out.println(e);}  
        return itemsList;
        
    }
     
        
     }
