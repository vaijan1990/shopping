/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Your Name <Vj>
 */
public class OrderDao {
    private static Connection con;
    public static int insertOrder(String userName,String concatId, String concatQty,String concatPrice){
        int orderId=0;
        String[] itemId=concatId.split(";");
        String[] quantity=concatQty.split(";");
        String[] price=concatPrice.split(";");
        
        orderId=getMaxOrder();
        
         try{          
            con=DBConnection.connect();
            String query="insert into shop.user_order(order_id,ORDER_USER_ID, ORDER_ITEM_ID,"
                    + "ORDER_QUANTITY,ORDER_PRICE,ORDER_TRANSACTION_STATUS) values "
                    +"(?,?,?,?,?,?)";
            PreparedStatement ps=con.prepareStatement(query);        
            for(int i=0;i<itemId.length;i++){
                ps.setInt(1, orderId);
                ps.setString(2, userName);
                ps.setInt(3, Integer.parseInt(itemId[i]));
                ps.setInt(4, Integer.parseInt(quantity[i]));
                ps.setFloat(5, Float.parseFloat(price[i]));
                ps.setString(6, "C");
                ps.executeUpdate();                
            }
        }
    catch(Exception e){System.out.println(e); 
                        orderId=0;
    }  
       
        return orderId;
    
        
    }
    
    public static int getMaxOrder(){
        int orderId=0;
        
         try{          
            con=DBConnection.connect();
            PreparedStatement ps=con.prepareStatement("select max(order_id)+1 as orderid from shop.user_order");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
            orderId=Integer.parseInt(rs.getString("orderid"));
            }
                
        }
    catch(Exception e){System.out.println(e);}  
       
        return orderId;
    }
    
    
}
