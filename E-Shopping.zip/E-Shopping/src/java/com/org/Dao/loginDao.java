/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Your Name <Vj>
 */
public class loginDao {
    private static Connection con;
    public static boolean validate(String name,String pass){  
boolean status=false;  
try{  
  
con=DBConnection.connect();
      
PreparedStatement ps=con.prepareStatement(  
"select * from shop.user where user_id=? and user_passwd=?");  
ps.setString(1,name);  
ps.setString(2,pass);  
      
ResultSet rs=ps.executeQuery();  
status=rs.next(); 
//con.close();
          
}catch(Exception e){System.out.println(e);}  
return status;  
}  
    
    
}  
    

