/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Your Name <Vj>
 */
public class DBConnection { 
   private static Connection con;
   private DBConnection() throws SQLException
    {
         
       try {  
           Class.forName("com.ibm.db2.jcc.DB2Driver");
           con=DriverManager.getConnection(  
"jdbc:db2://localhost:50000/sample","db2admin","db2admin"); 
       } catch (ClassNotFoundException | SQLException ex) {
           ex.printStackTrace();
       }
 
    }
   
   public static Connection connect() throws SQLException {
               if (con != null) {
                   System.out.println("connection is not null");
                       return con;
               } else {

                       DBConnection db = new DBConnection();
                       return db.con;
               }
    
}
}
