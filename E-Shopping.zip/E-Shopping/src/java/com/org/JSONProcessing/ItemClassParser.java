/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.JSONProcessing;

/**
 *
 * @author Your Name <Vj>
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import static java.security.AccessController.getContext;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import static javax.servlet.SessionTrackingMode.URL;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author VJ
 */
public class ItemClassParser {
 public static Boolean validateUser(String username, String userpass) throws IOException {
        Boolean validUser=false;
       System.out.println(new File(".").getAbsolutePath());
        JSONParser parser=new JSONParser();
        try {
            String file = ItemClassParser.class.getClassLoader().getResource("/JSON/credentials.json").getFile();
            FileReader fs=new FileReader(file);
            Object obj=parser.parse(fs);
            JSONObject jsonObject=(JSONObject) obj;
            String loginid;
            String password;            
            int i=0;
            JSONArray credClass=(JSONArray) jsonObject.get("credentials");
            
            for (Object prdClas : credClass) {
                JSONObject credObj = (JSONObject) credClass.get(i);
                loginid=(String) credObj.get("username");
                if (loginid.equals(username)){
                    password=(String) credObj.get("password");
                    if (password.equals(userpass)){
                        System.out.println("valid user");
                        validUser=true;
                        break;
                    }
                    else{
                        validUser=false;
                        break;
                    }
                        
                }
                    fs.close();
                    break;                    
                }                
            }                     
         catch (FileNotFoundException ex) {
            Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
        }       
        System.out.println(validUser);
     return validUser;
    }
   
 
 public static String[] getProducts(int clsId) throws IOException {
        
        String file = ItemClassParser.class.getClassLoader().getResource("/JSON/products.json").getFile();
        ArrayList prodArray=new ArrayList();
        JSONParser parser=new JSONParser();
        try {
            String itemList[];
            FileReader fs=new FileReader(file);
            Object obj=parser.parse(fs);
            JSONObject jsonObject=(JSONObject) obj;
            String itemId;
            String itemName;
            String itemImageName;
            String itemUnitPrice;
            String itemDiscountPercent;
            
            String separator=";";
            
            JSONArray prdClass=(JSONArray) jsonObject.get("superClass");
            String classId;
            for (Object prdClas : prdClass) {
                JSONObject classObj = (JSONObject) prdClas;
                classId=(String) classObj.get("classId");
                System.out.println("class id is " +classId);
                System.out.println("Looping now");
                if(classId.equals(Integer.toString(clsId))){
                    JSONArray itemArray=(JSONArray) classObj.get("classItems");
                    itemList=new String[itemArray.size()+1];
                    for(int j=0;j<itemArray.size();j++){
                        JSONObject itemObj=(JSONObject) itemArray.get(j);
                        itemId=(String) itemObj.get("itemId");
                        System.out.println("itemId" +itemId);
                        itemName=(String) itemObj.get("itemName");
                        itemImageName=(String) itemObj.get("itemImageName");
                        itemUnitPrice=(String) itemObj.get("itemPrice");
                        itemDiscountPercent=(String) itemObj.get("itemDiscount");
                        prodArray.add(itemId+ separator+ itemName+ separator+itemImageName+ separator+itemUnitPrice+ separator+itemDiscountPercent);                        
                        System.out.println(prodArray.get(j));                        
                    }
                    fs.close();
                    System.out.println("closing file");
                    
                    break;                    
                }                
            }
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
  
        }
        System.out.println("parsing now" +prodArray.size());
        
        String[] productList = new String[prodArray.size()];
        productList=(String[]) prodArray.toArray(productList);

        return productList; 
        
        
 }
  
 
 public static String[] getCartItems(String order_item)
    {
        String file = ItemClassParser.class.getClassLoader().getResource("/JSON/products.json").getFile();
        String[] cart_items=order_item.split(";");
        
        String itemId="";
        String itemName;
        String itemImageName;
        String itemUnitPrice;
        String itemDiscountPercent;
        ArrayList prodArray=new ArrayList();
        String separator=";";
 
        FileReader fs;
     try {
         fs = new FileReader(file);
         int classCount=0;
        
        JSONParser parser=new JSONParser();
        Object obj=parser.parse(fs);
        JSONObject jsonObject=(JSONObject) obj;
        
        for (int i=0;i<cart_items.length;i++){
           JSONArray prdClass=(JSONArray) jsonObject.get("superClass");
           for (Object prdClas : prdClass) {
               JSONObject classObj = (JSONObject) prdClas;
               JSONArray itemArray=(JSONArray) classObj.get("classItems");
               for(int j=0; j< itemArray.size(); j++){
               JSONObject itemObj=(JSONObject) itemArray.get(j);
               itemId=(String) itemObj.get("itemId");
               if(itemId.equals(cart_items[i])){
                        itemName=(String) itemObj.get("itemName");
                        itemImageName=(String) itemObj.get("itemImageName");
                        itemUnitPrice=(String) itemObj.get("itemPrice");
                        itemDiscountPercent=(String) itemObj.get("itemDiscount");
                        prodArray.add(itemId+ separator+ itemName+ separator+itemImageName+ separator+itemUnitPrice+ separator+itemDiscountPercent);
               }
           }
           }
           
        }

 
  }
     catch (FileNotFoundException ex) {
         Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
     } catch (IOException ex) {
         Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
     } catch (ParseException ex) {
         Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
     }
     String[] itemsList=new String[prodArray.size()] ;
     itemsList=(String[]) prodArray.toArray(itemsList);
     return itemsList;
    }

public static String insertOrder(String userName,String concatId, String concatQty,String concatPrice)
    {
        String file = ItemClassParser.class.getClassLoader().getResource("/JSON/orders.json").getFile();
        FileReader fr=null;
        System.out.println(concatId+concatQty+concatPrice);
        String[] itemsId=concatId.split(";");
        String[] itemQty=concatQty.split(";");
        String[] itemPrice=concatPrice.split(";");
        String orderId=UUID.randomUUID().toString();
        String returnId=orderId;
        
        Date date=new Date();
        String orderTime=new Timestamp(date.getTime()).toString();
        
        try {
         fr = new FileReader(file);
         System.out.println("reading file now");
         JSONParser parser=new JSONParser();
         System.out.println("Parsing file now");
         Object obj=parser.parse(fr);
         JSONObject jsonObject=(JSONObject) obj;
         JSONArray jsonClass=(JSONArray) jsonObject.get("orders");
         JSONObject newOrder=new JSONObject();
         for(int i=0; i < itemsId.length; i++){
             System.out.println("itemid + qty"  + itemsId[i] +itemQty[i]);
             System.out.println("price"  + itemPrice[i]);
             newOrder.put("orderId", orderId);
             newOrder.put("orderTime", orderTime);
             newOrder.put("userName", userName);
             System.out.println(userName);
             newOrder.put("itemsId", itemsId[i]);
             newOrder.put("itemQty",itemQty[i]);
             newOrder.put("itemPrice",itemPrice[i]);
             jsonClass.add(newOrder);
         }
         fr.close(); 
         FileWriter fw=new FileWriter(file);
         fw.write(jsonObject.toJSONString());   
         fw.flush();
         fw.close();

         
         
     } catch (FileNotFoundException ex) {
         Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
         returnId="0";
     } catch (IOException ex) {
         Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
         returnId="0";
     } catch (ParseException ex) {
         Logger.getLogger(ItemClassParser.class.getName()).log(Level.SEVERE, null, ex);
         returnId="0";
     } 
     return returnId;        
    }
}

