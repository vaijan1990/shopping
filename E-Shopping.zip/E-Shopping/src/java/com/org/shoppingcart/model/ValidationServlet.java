package com.org.shoppingcart.model;


import com.org.JSONProcessing.ItemClassParser;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Your Name Vj
 */
public class ValidationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
        String forwardURL="";
        String userName=request.getParameter("username");
        String password=request.getParameter("userpass");
      
        //validating with inputs from credentials.json
        if(ItemClassParser.validateUser(userName,password )){
        //Addind session variables    
        HttpSession session = request.getSession();
        session.setAttribute("user", userName);
        session.setMaxInactiveInterval(30*60);
        forwardURL="/welcome.jsp";  
       // request.setAttribute("userName", userName);
        }    
        else {
        forwardURL="/index.jsp";
        String errorMessage="Invalid Credentials";
        request.setAttribute("errMsg",errorMessage );   
    
        }
        RequestDispatcher rd=getServletContext().getRequestDispatcher(forwardURL);
        rd.forward(request, response);
        }   

 }
