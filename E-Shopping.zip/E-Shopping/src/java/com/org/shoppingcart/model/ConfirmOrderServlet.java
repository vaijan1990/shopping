/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.shoppingcart.model;


import com.org.JSONProcessing.ItemClassParser;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Your Name <Vj>
 */
public class ConfirmOrderServlet extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          String forwardURL="";
          HttpSession session = request.getSession();
          String userName=(String) session.getAttribute("user");
          String itemsConfirmed=request.getParameter("itemId_Confirmed");
          String quantityConfirmed=request.getParameter("quantity_Confirmed");
          String priceConfirmed=request.getParameter("price_Confirmed");
          
          System.out.println("in servlet "+userName +itemsConfirmed +quantityConfirmed +priceConfirmed);
          
          
          String orderId=ItemClassParser.insertOrder(userName,itemsConfirmed,quantityConfirmed,priceConfirmed);
          if (!orderId.equals("0"))
          {
              forwardURL="/orderSuccess.jsp";
              request.setAttribute("orderId", orderId);
          }
          else
          {
              forwardURL="/error.jsp";
          }
          
        
         RequestDispatcher rd=getServletContext().getRequestDispatcher(forwardURL);
        rd.forward(request, response);
    }

    
}
