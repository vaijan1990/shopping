/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.org.shoppingcart.model;

import com.org.Dao.OrderDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Your Name <Vj>
 */
public class confirmOrder extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          String forwardURL="";
          
          String userName=request.getParameter("username");
          String itemsConfirmed=request.getParameter("itemId_Confirmed");
          String quantityConfirmed=request.getParameter("quantity_Confirmed");
          String priceConfirmed=request.getParameter("price_confirmed");
          
          System.out.println("in servlet "+userName +itemsConfirmed +quantityConfirmed +priceConfirmed);
          
          
          int orderId=OrderDao.insertOrder(userName,itemsConfirmed,quantityConfirmed,priceConfirmed);
          if (orderId==0)
          {
              forwardURL="/error.jsp";
          }
          else
          {
              forwardURL="/orderSuccess.jsp";
              request.setAttribute("orderId", orderId);
          }
          
        
         RequestDispatcher rd=getServletContext().getRequestDispatcher(forwardURL);
        rd.forward(request, response);
    }

    
}
