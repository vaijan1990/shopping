/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function addCart() {
    //var checkedValue=document.getElementById("orderedItems").value;
    //get from local storage
    var checkedValue="";
    if(localStorage.getItem("productid"))
        {
        checkedValue=localStorage.getItem("productid");
        }
    var productSelected=document.getElementsByClassName('productCheckBox');
    var splitcheckedValue=checkedValue.split(";");
    var splitcheckedValuelength=splitcheckedValue.length;
    var existingProduct="";
    var appendValue="";
    prdlength=productSelected.length;
    var flag=true;
    
     for(var i=0;i<prdlength;i++)
    {
        if(productSelected[i].checked)
        {
            for(var j=0;j<splitcheckedValuelength;j++)
            {
            if(productSelected[i].value===splitcheckedValue[j])
            {
                flag=false;
                existingProduct=productSelected[i].value;
            }
            }
        }
    }
    if(flag==true)
    {
    for(var i=0;i<prdlength;i++)
    {
        if(productSelected[i].checked)
        {
            if(checkedValue!=="")
            {
                checkedValue  += ";"; 
                appendValue=";";
                
            }
        
            checkedValue+=productSelected[i].value; 
        }
    }
    }
    else if(flag===false){
        alert(existingProduct+ "is already selected");
    }
    document.getElementById("orderedItems").value=checkedValue; 
    //setting local storage as the slected items
    if(typeof(Storage) !== "undefined") {
      localStorage.setItem("productid",checkedValue );
  }
}
