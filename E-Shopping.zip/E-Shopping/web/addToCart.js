/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function addCart() {
    var checkedValue="";
   
    var productSelected=document.getElementsByClassName('productCheckBox');
    prdlength=productSelected.length;
   
        for(var i=0;i<prdlength;i++)
    {
        if(productSelected[i].checked)
        {
            if(checkedValue!="")
            {
                checkedValue  += ";";    
            }
        
            checkedValue+=productSelected[i].value;       
        }
    }
    document.getElementById("orderedItems").value=checkedValue;
      
    
}
